"""
Schema definitions for the API
"""
