"""
Store Price API application package
"""
