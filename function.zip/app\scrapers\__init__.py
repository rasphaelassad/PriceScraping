"""
Web scraper implementations for different stores
"""
